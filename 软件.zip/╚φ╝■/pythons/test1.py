with open("C:\\inetpub\\wwwroot\\Data\\now_freq.txt",'r',encoding='utf-8') as now_freq_read:
    lines=now_freq_read.readlines()
    if(lines[0]!=''):
        current_freq=float(lines[0])
print(current_freq)
